package responses;

public class FillResult {

    /**
     * status message
     */
    public String message;

    /**
     * success or not
     */
    public boolean success = false;


}
