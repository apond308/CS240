package responses;

public class ClearResult {

    /**
     * status message
     */
    public String message;

    /**
     * success or not
     */
    public boolean success = false;

}
